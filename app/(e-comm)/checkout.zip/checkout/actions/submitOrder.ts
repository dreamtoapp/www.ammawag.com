export const submitOrder = (
  name: string,
  phone: string,
  location: [number, number] | null,
  address: string
) => {
  if (!name || !phone || !location) {
    alert("يرجى ملء جميع الحقول وتأكيد الموقع.");
    return;
  }
  if (!/^\d+$/.test(phone)) {
    alert("رقم الجوال يجب أن يكون أرقام فقط.");
    return;
  }

  const googleMapsLink = location
    ? `https://www.google.com/maps?q=${location[0]},${location[1]}`
    : `https://www.google.com/maps?q=21.5433,39.1728`;

  console.log({ name, phone, location, address, googleMapsLink });
  alert(`تم تأكيد الطلب بنجاح!\n\nرابط الموقع: ${googleMapsLink}`);
};
