"use client";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { useGeolocation } from "./hooks/useGeolocation";
import { LocationSelector } from "./components/LocationSelector";
import { ConfirmCheckbox } from "./components/ConfirmCheckbox";
import CartSummary from "../cart/component/CartSummary";

export default function ConfirmOrderPage() {
  const {
    location,
    latSpring,
    lngSpring,
    isGeolocationAvailable,
    isGeolocationEnabled,
    getPosition,
  } = useGeolocation();
  const [manualAddress, setManualAddress] = useState<string>("");
  const [useManualAddress, setUseManualAddress] = useState<boolean>(false);
  const [isClient, setIsClient] = useState(false);
  const [isLocationConfirmed, setIsLocationConfirmed] =
    useState<boolean>(false);

  useEffect(() => {
    setIsClient(true); // Mark as hydrated
  }, []);

  if (!isClient) {
    return null; // Render nothing until hydration completes
  }

  return (
    <main className=" relative w-full mb-10 flex items-start justify-center flex-col lg:flex-row bg-white dark:bg-gray-800 shadow-lg rounded-2xl p-6 ">
      <div className="flex items-center justify-start flex-col w-full lg:w-1/2 gap-2 ">
        <h1 className="text-3xl font-bold text-center">📝 تأكيد الطلب</h1>
        <CartSummary />
      </div>

      <div className="flex items-center justify-start flex-col w-full lg:w-1/2 gap-2">
        <LocationSelector
          {...{
            location,
            latSpring,
            lngSpring,
            isGeolocationAvailable,
            isGeolocationEnabled,
            getPosition,
            useManualAddress,
            manualAddress,
            setManualAddress,
            setUseManualAddress,
          }}
        />

        <ConfirmCheckbox {...{ isLocationConfirmed, setIsLocationConfirmed }} />
      </div>

      <FotterButton />
    </main>
  );
}

const FotterButton = () => {
  return (
    <div className="fixed bottom-0 left-0  h-14 bg-gray-300 w-full flex items-center justify-center">
      <Button
        // disabled={!isLocationConfirmed}
        className="w-[80%] py-3 text-lg font-semibold transition-all duration-200 hover:scale-105"
      >
        تأكيد الطلب
      </Button>
    </div>
  );
};
