"use client";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { motion, AnimatePresence } from "framer-motion";
import MapEmbed from "./MapEmbed";
import { useGeolocation } from "../hooks/useGeolocation";

interface LocationSelectorProps {
  location: [number, number] | null;
  latSpring: any;
  lngSpring: any;
  isGeolocationAvailable: boolean;
  isGeolocationEnabled: boolean;
  getPosition: () => void;
  useManualAddress: boolean;
  manualAddress: string;
  setManualAddress: (value: string) => void;
  setUseManualAddress: (value: boolean) => void;
}

const CoordinatesDisplay = ({
  latSpring,
  lngSpring,
}: {
  latSpring: any;
  lngSpring: any;
}) => (
  <p className="text-center text-lg text-gray-700  font-medium mt-4">
    📍 الموقع الحالي:{" "}
    <motion.span
      key={`lat-${latSpring}`}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      {latSpring}
    </motion.span>
    ,{" "}
    <motion.span
      key={`lng-${lngSpring}`}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      {lngSpring}
    </motion.span>
  </p>
);

const RetryButton = ({ onClick }: { onClick: () => void }) => (
  <Button
    variant="secondary"
    onClick={onClick}
    className="shadow-lg rounded-full px-4 py-2 text-lg"
  >
    🔄 تحديث الموقع
  </Button>
);

const LocationStatus = ({
  isGeolocationAvailable,
  isGeolocationEnabled,
}: {
  isGeolocationAvailable: boolean;
  isGeolocationEnabled: boolean;
}) => {
  if (!isGeolocationAvailable)
    return (
      <p className="text-sm text-red-500 text-center font-medium">
        ❌ جهازك لا يدعم خاصية تحديد الموقع.
      </p>
    );
  if (!isGeolocationEnabled)
    return (
      <p className="text-sm text-yellow-500 text-center font-medium">
        ⚠️ الرجاء تفعيل GPS لاستخدام هذه الميزة.
      </p>
    );
  return null;
};

const LocationDisplay = ({
  location,
  latSpring,
  lngSpring,
  getPosition,
}: {
  location: [number, number];
  latSpring: any;
  lngSpring: any;
  getPosition: () => void;
}) => (
  <AnimatePresence mode="wait">
    <motion.div
      key={location.join(",")}
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 10 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="space-y-4 w-full"
    >
      <MapEmbed location={location} />
    </motion.div>
    <div className="flex flex-col items-center space-y-3">
      <CoordinatesDisplay latSpring={latSpring} lngSpring={lngSpring} />
      <RetryButton onClick={getPosition} />
    </div>
  </AnimatePresence>
);

export function LocationSelector({
  useManualAddress,
  manualAddress,
  setManualAddress,
  setUseManualAddress,
}: LocationSelectorProps) {
  const [isMounted, setIsMounted] = useState(false);
  const {
    location,
    latSpring,
    lngSpring,
    isGeolocationAvailable,
    isGeolocationEnabled,
    getPosition,
  } = useGeolocation();

  useEffect(() => {
    setIsMounted(true);
  }, []);

  if (!isMounted) {
    return <Skeleton className="w-full h-[300px] rounded-lg shadow-md" />;
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      className="bg-white  rounded-2xl shadow-xl p-6 space-y-6 max-w-4xl w-full"
    >
      {!useManualAddress ? (
        <>
          <LocationStatus
            isGeolocationAvailable={isGeolocationAvailable}
            isGeolocationEnabled={isGeolocationEnabled}
          />
          {location ? (
            <div className="flex flex-col items-center">
              <LocationDisplay
                location={location}
                latSpring={latSpring}
                lngSpring={lngSpring}
                getPosition={getPosition}
              />
            </div>
          ) : (
            <Skeleton className="w-full h-[300px] rounded-lg shadow-lg" />
          )}
        </>
      ) : (
        <input
          type="text"
          value={manualAddress}
          onChange={(e) => setManualAddress(e.target.value)}
          placeholder="مثال: شارع الملك فهد، الرياض، السعودية"
          className="w-full p-3 border border-gray-300   rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500  "
        />
      )}
      <Button
        variant="ghost"
        className="w-full mt-2 text-lg font-medium text-gray-700   hover:bg-gray-100  rounded-lg p-3 transition"
        onClick={() => setUseManualAddress(!useManualAddress)}
      >
        {useManualAddress
          ? "🔄 استخدام الخريطة بدلاً من الإدخال اليدوي"
          : "✏️ إدخال العنوان يدويًا"}
      </Button>
    </motion.div>
  );
}
