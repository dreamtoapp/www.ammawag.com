// components/ConfirmCheckbox.tsx
import { Checkbox } from "@/components/ui/checkbox";

interface ConfirmCheckboxProps {
  isLocationConfirmed: boolean;
  setIsLocationConfirmed: (value: boolean) => void;
}

export function ConfirmCheckbox({
  isLocationConfirmed,
  setIsLocationConfirmed,
}: ConfirmCheckboxProps) {
  return (
    <div className="flex items-center space-x-3 mt-4 gap-4">
      <Checkbox
        checked={isLocationConfirmed}
        onCheckedChange={(checked: boolean | "indeterminate") =>
          setIsLocationConfirmed(checked === true)
        }
        className="w-6 h-6 border-2 border-green-500 text-green-600 rounded-md focus:ring-2 focus:ring-green-500 transition-all"
      />
      <label className="text-gray-700   font-medium cursor-pointer">
        تأكيد الموقع أو العنوان المدخل يدويًا
      </label>
    </div>
  );
}
