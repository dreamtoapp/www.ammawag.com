import { useState, useEffect } from "react";
import { Skeleton } from "@/components/ui/skeleton"; // Example for skeleton loading
import { Button } from "@/components/ui/button"; // Example button component

const MapEmbed = ({ location }: { location?: [number, number] }) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const isValidLocation =
    Array.isArray(location) &&
    location.length === 2 &&
    typeof location[0] === "number" &&
    typeof location[1] === "number";

  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 1500); // Simulate loading effect
    return () => clearTimeout(timer);
  }, []);

  if (!isValidLocation) {
    return (
      <div className="flex flex-col items-center justify-center text-center p-6">
        <p className="text-gray-500   text-lg">📍 Location not available.</p>
      </div>
    );
  }

  return (
    <div className="relative w-full max-w-3xl mx-auto">
      {!isLoaded && (
        <Skeleton className="w-full h-[400px] rounded-lg" /> // Beautiful loading effect
      )}

      {isLoaded && (
        <iframe
          title="Google Maps"
          width="100%"
          height="300"
          className="rounded-lg shadow-md"
          loading="lazy"
          allowFullScreen
          src={`https://www.google.com/maps?q=${encodeURIComponent(
            location[0]
          )},${encodeURIComponent(location[1])}&output=embed`}
        />
      )}
    </div>
  );
};

export default MapEmbed;
