// hooks/useGeolocation.ts
"use client"; // ✅ Forces this to run only in the browser

import { useState, useEffect } from "react";
import { useGeolocated } from "react-geolocated";
import { animate, useSpring } from "framer-motion";

export type LocationType = [number, number] | null;

export function useGeolocation() {
  const [location, setLocation] = useState<LocationType>(null);
  const isClient = typeof window !== "undefined"; // ✅ Check if we are in the browser

  const { coords, isGeolocationAvailable, isGeolocationEnabled, getPosition } =
    isClient
      ? useGeolocated({
          positionOptions: { enableHighAccuracy: true },
          userDecisionTimeout: 10000,
        })
      : {
          coords: null,
          isGeolocationAvailable: false,
          isGeolocationEnabled: false,
          getPosition: () => {},
        };

  const latSpring = useSpring(0, { stiffness: 100, damping: 20 });
  const lngSpring = useSpring(0, { stiffness: 100, damping: 20 });

  useEffect(() => {
    if (coords) {
      setLocation([coords.latitude, coords.longitude]);
      animate(latSpring, coords.latitude + Math.random() * 0.0005, {
        duration: 0.7,
      });
      animate(lngSpring, coords.longitude + Math.random() * 0.0005, {
        duration: 0.7,
      });
    }
  }, [coords]);

  return {
    location,
    latSpring,
    lngSpring,
    isGeolocationAvailable,
    isGeolocationEnabled,
    getPosition,
  };
}
